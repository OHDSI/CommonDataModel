Common-Data-Model / Netezza
=================

This folder contains the script for Netezza. 
